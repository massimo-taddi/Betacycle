﻿using System.Net;
using System.Net.Mail;

namespace Prova_con_entry_point
{
    internal class Program
    {
        static void Main (string[] args)
        {

            MailMessage mail=new MailMessage();
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress("beta89256464@gmail.com");
            mail.To.Add("massimo.taddi02@gmail.com");
            mail.Subject = "prova";
            mail.Body = "provatesto";
            
            //password originale betaprova123

            
            smtpClient.Port = 587;
            smtpClient.Credentials = new NetworkCredential("beta89256464@gmail.com", "ooriltjjyrjekmvi");
            smtpClient.EnableSsl = true;
            smtpClient.Send(mail);
        }
    }
}
